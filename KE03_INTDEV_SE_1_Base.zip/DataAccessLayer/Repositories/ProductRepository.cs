﻿using DataAccessLayer.Interfaces;
using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly MatrixIncDbContext _context;

        public ProductRepository(MatrixIncDbContext context)

        {
            _context = context;
        }

        public IEnumerable<Product> GetAllProducts()

        {
            return _context.Products.ToList();
        }

        public Product? GetProductById(int id)

        {
            return _context.Products.FirstOrDefault(p => p.Productnummer == id);
        }

    }
}
